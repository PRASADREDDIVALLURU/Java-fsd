package methods;

public class Methoddemo {
	public int addition(int x,int y) {
		int z = x+y;
		return z;
	}
	public static void main(String[] args){
		Methoddemo obj = new Methoddemo();
		int add = obj.addition(3,5);
		System.out.println("Addition of 2 numbers : "+add);
	}

}
