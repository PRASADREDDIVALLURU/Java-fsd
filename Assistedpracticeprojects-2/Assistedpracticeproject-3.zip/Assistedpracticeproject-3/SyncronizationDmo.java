
public class SyncronizationDmo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Sender snd = new Sender(); 
        Threadsender Sender1 = new Threadsender( " started" , snd ); 
        Threadsender Sender2 = new Threadsender( " ended " , snd ); 
        Sender1.start(); 
        Sender2.start(); 
        try
        { 
            Sender1.join(); 
            Sender2.join(); 
        } 
        catch(Exception e) 
        { 
            System.out.println("Interrupted"); 
        }

	}

}
