
public class Threadsender extends Thread{


		// TODO Auto-generated method stub
		private String message; 
	    private Thread thread; 
	    Sender  sender; 
	    Threadsender(String msg,  Sender obj) 
	    { 
	        message = msg; 
	        sender = obj; 
	    }
	    public void run() 
	    {  
	        synchronized(sender) 
	        { 
	            sender.send(message); 
	        } 
	    }

	}


