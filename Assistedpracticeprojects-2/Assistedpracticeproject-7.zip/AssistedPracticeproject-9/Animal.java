interface Animal {
    void makeSound();
}