class Bat implements Mammal, Bird {
    @Override
    public void makeSound() {
        System.out.println("Chirp Chirp");
    }

    @Override
    public void run() {
        System.out.println("Bat is running");
    }

    @Override
    public void fly() {
        System.out.println("Bat is flying");
    }
}