interface Bird extends Animal {
    void fly();
}