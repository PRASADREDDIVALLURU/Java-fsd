public class DiamondProblemExample {
    public static void main(String[] args) {
        // Creating an instance of the Bat class
        Bat bat = new Bat();

        // Calling methods from both Mammal and Bird interfaces
        bat.makeSound();
        bat.run();
        bat.fly();
    }
}