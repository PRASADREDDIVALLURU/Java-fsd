interface Mammal extends Animal {
    void run();
}