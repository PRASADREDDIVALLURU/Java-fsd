
public class MyThreadClass extends Thread {
	public void run()
	{
		System.out.println("user thread running");
		}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyThreadClass thread = new MyThreadClass();
		thread.start();
		System.out.println("Main thread running");
	}

}
