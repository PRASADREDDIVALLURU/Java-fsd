
public class ExampleException extends Exception{

    public ExampleException(String s) 
    { 
        super(s); 
    } 


}
