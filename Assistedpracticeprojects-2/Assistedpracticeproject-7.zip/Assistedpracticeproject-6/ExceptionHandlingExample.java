import java.util.Scanner;

public class ExceptionHandlingExample {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            
            System.out.print("Enter the first number: ");
            int num1 = Integer.parseInt(scanner.nextLine());

            System.out.print("Enter the second number: ");
            int num2 = Integer.parseInt(scanner.nextLine());

            
            double result = divideNumbers(num1, num2);

            
            System.out.println("Result of division: " + result);

        } catch (NumberFormatException e) {
            System.out.println("Error: Please enter valid integers.");
        } catch (ArithmeticException e) {
            System.out.println("Error: Cannot divide by zero.");
        } finally {
            
            scanner.close();
        }
    }

    // A method that may throw an ArithmeticException
    static double divideNumbers(int dividend, int divisor) {
        if (divisor == 0) {
            // Throwing ArithmeticException if the divisor is zero
            throw new ArithmeticException("Cannot divide by zero.");
        }
        return (double) dividend / divisor;
    }
}
