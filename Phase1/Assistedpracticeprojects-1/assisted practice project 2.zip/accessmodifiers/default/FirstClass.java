package defpack.de.fault;

public class FirstClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SecondClass object = new SecondClass();
		object.DisplayDefault();
	}

}
