package defpack.de.fault;

public class SecondClass {
	
	void DisplayDefault() {
		System.out.println("Default access modifier");
	}
}
