
public class defprivateclass {
	private void DisplatProtect() {
		System.out.println("private access modifier ");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		defprivateclass object = new defprivateclass();
		object.DisplatProtect();

	}

}
