package defpackage.pack.protectt;

public class Secondclass {
	protected void DisplayProtect(){
		System.out.println("protected acess modifier");
	}

}
