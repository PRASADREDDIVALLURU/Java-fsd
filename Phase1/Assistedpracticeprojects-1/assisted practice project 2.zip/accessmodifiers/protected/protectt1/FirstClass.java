package defpackage.pack.protectt1;
import defpackage.pack.protectt.*;
public class FirstClass extends Secondclass{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		FirstClass object = new FirstClass();
		object.DisplayProtect();
	}

}
