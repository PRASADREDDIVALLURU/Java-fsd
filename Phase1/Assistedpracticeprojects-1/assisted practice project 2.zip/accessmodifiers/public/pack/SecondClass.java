package defpublic.pack;

public class SecondClass {
	public int PublicVariable = 5 ;
	
	public void DisplayPublic(){
		System.out.println("public access modifiers ");
	}

}
