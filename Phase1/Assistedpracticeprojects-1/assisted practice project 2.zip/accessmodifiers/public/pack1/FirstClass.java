package defpublic.pack1;
import defpublic.pack.*;
public class FirstClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SecondClass object= new SecondClass();
		object.DisplayPublic();
	}

}
