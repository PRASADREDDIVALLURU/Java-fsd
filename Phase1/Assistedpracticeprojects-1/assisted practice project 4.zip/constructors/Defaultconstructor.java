package constructors;

public class Defaultconstructor {
	// This is the default constructor
	public Defaultconstructor() {
        // Constructor code, if needed
        System.out.println("Default constructor called");
    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Creating an object of MyClass
		Defaultconstructor myObject = new Defaultconstructor();
		    }
}
	


