package constructors;

public class ParameterizedConstructor {
	int id;
	String name;
	ParameterizedConstructor(int i,String n){
		id=i;
		name=n;
	}
	void display() {
	System.out.println(id+" "+name);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ParameterizedConstructor pc1 = new ParameterizedConstructor(1,"prasad");
		ParameterizedConstructor pc2 = new ParameterizedConstructor(2,"reddy");
		pc1.display();
		pc2.display();
	}

}
