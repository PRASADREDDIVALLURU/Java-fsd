
public class ExampleMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
        { 
            throw new ExampleException("temp"); 
        } 
        catch (ExampleException ex) 
        { 
            System.out.println("Caught"); 
            System.out.println(ex.getMessage()); 
        }

	}

}
