
public class ExampleThrow {
	static void checkAge(int age) {
        if (age < 18) {
            // Creating an instance of ArithmeticException and throwing it
            throw new ArithmeticException("Age cannot be less than 18");
        } else {
            System.out.println("You are eligible to vote");
        }
    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
            // Calling the method with an age that triggers an exception
            checkAge(15);
        } catch (ArithmeticException e) {
            // Handling the exception
            System.out.println("Exception caught: " + e.getMessage());
        }

	}

}
