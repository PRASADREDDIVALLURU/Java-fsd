
public class ExampleThrows {
	void Division() throws ArithmeticException
    {
        int a=45,b=0,c;
        c = a / b;
        System.out.print("\n\tThe result is : " + c);
    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ExampleThrows obj = new ExampleThrows();
		try
        {
            obj.Division();
        }
        catch(ArithmeticException Ex)
        {
            System.out.print("\n\tError : " + Ex.getMessage());
        }
        System.out.print("\n\tEnd of program.");

	}

}
