package innerclass;

public class Outerclass {
	private int outvar = 7;
	public class InnerClass{
		public void display() {
			System.out.println("Inner class method: " + outvar);
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Outerclass outerObject = new Outerclass();
		Outerclass.InnerClass innerObject = outerObject.new InnerClass();
		innerObject.display();

	}

}
