package typecasting;

public class ImplicitExplicitTypeCasting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Implicit Type Casting
		System.out.println("Implicit Type Casting");
		byte b = 2;
		System.out.println("byte : "+b);
		short s = b;
		System.out.println("byte to short : "+s);
		//char c = s;
		//System.out.println("char : "+c);
		int i = s;
		System.out.println("short to int : "+i);
		long l = i;
		System.out.println("int to long : "+l);
		float f = l;
		System.out.println("long to float : "+f);
		double d = f;
		System.out.println("float to double : "+d);
		System.out.println();
		//Explicit Type Casting
		System.out.println("Explicit Type Casting");
		double dd = 9.76d;
		System.out.println("double : "+dd);
		float ff = (float) dd;
		System.out.println("double to float : "+ff);
		long ll = (long) ff;
		System.out.println("float to long : "+ll);
		int ii = (int) ll;
		System.out.println("long to int : "+ii);
		short ss = (short) ii;
		System.out.println("int to short : "+ss);
		byte bb = (byte)ss;
		System.out.println("short to byte : "+bb);
	}

}
